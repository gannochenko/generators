module.exports = {
    handler: (event, context, callback) => {
        return callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/html; charset=utf-8',
                'Access-Control-Allow-Origin': '*',
            },
            body: 'Ok',
        });
    }
};
